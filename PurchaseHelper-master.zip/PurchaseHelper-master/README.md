# PurchaseHelper

Sample app to explain the In-App purchase implementation in Android using Play-billing library

![ScreenShot](https://droidmentor.com/wp-content/uploads/2018/09/InApp_purchase_demo.jpg)

**Note:**

Before executing the project you have to change the **“applicationId”** in the build.gradle(app) and also the **“product_id”** in the city_list.json file which is in the assets folder.

For more information, check out my detailed guide here :  https://droidmentor.com/inapppurchase-subscription/
