package com.droidmentor.purchasehelper.ClickListener;

import android.view.View;

/**
 * Created by Jaison.
 */
public interface CityListingClickListener {
     void onItemClick(View v, int position);
     void onItemPurchaseClick(View v, int position);
}
